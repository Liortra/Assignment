#ifndef FUNC_H_
#define FUNC_H_

#define True 1
#define False 0

void initString(char *str,int length);
char* myGets(char* buf,int size);
void printString(char *str);
int countWords(char *str);
void longestInCaptital(char *str);
void revertWords(char *str);
void eraseCharsFromString(char *str, const char* symbols);
int isPalindrome(const char *str);
char* myGets(char* buf,int size);

#endif /* FUNC_H_ */
