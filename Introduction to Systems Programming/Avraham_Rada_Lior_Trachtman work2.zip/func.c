#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "func.h"

//----------------------------------------------------------------------------------
void initString(char *str,int length)
{
	getchar(); // cleaning buffer
	printf("Please enter a string: ");
	myGets(str,length);
}

// Method for getting 'clean' string without '\n' in the end
char* myGets(char* buf,int size)
{
	if (buf != NULL && size > 0)
	{
		if(fgets(buf,size,stdin))
		{
			buf[strcspn(buf,"\n")] = '\0';
			return buf;
		}
		*buf = '\0';
	}
	return NULL;
}

//----------------------------------------------------------------------------------
void printString(char *str)
{
	printf("Your string is: ");
	puts(str);
}

//----------------------------------------------------------------------------------
int countWords(char *str)
{
	char newStr[strlen(str) + 1];
	char uniq[]={' ',',','?',':','-'};
	strcpy(newStr,str);

	int countOfWords = 0;
	char* words;

	words = strtok(newStr,uniq);
	while(words != NULL)
	{
		countOfWords++;
		words = strtok(NULL,uniq);
	}
	return countOfWords;
}

//----------------------------------------------------------------------------------
void longestInCaptital(char *str)
{
	int i,start=0,longest=0,longest_pos=0,ending_pos=0;;
	for(i=0;str[i]!='\0';i++)
	{
		if(!isalpha(str[i]))
			start=i+1;
		else
		{
			if(i-start>longest)
			{
				longest=i-start;
				longest_pos=start;
				ending_pos=i;
			}
		}
	}
	for(i=longest_pos;i<=ending_pos;i++)
		str[i]=toupper(str[i]);
}

//----------------------------------------------------------------------------------
void revertWords(char *str)
{
	int i = 0,j = 0;
	int len = strlen(str) + 1;
	char temp[len];
	int start = 0;
	while(str[i] != '\0')
	{
		if(isalpha(str[i]))
		{
			temp[j]=str[i];
			j++;
		}
		else
		{
			if(str[i] == '?' || str[i] == ',' || str[i] == ' ' || str[i] == '-' || str[i] == ':')
				str[i] = '*';
			temp[j] = str[i];

			i = start;
			while(j != start)
				str[i++] = temp[--j];
			start = j=  i+1;
		}
		i++;
	}

	i = start;
	while(j != start)
		str[i++] = temp[--j];
}

//----------------------------------------------------------------------------------
void eraseCharsFromString(char *str, const char* symbols)
{
	char newStr[strlen(str) + 1];
	char* words = strtok(str,symbols);

	while(words != NULL)
	{
		strcat(newStr,words);
		words = strtok(NULL,symbols);
	}
	strcpy(str,newStr);
}

//----------------------------------------------------------------------------------
int isPalindrome(const char *str)
{
	const char* start = str;
	const char* end = (strlen(str) + str);
	while(start < end)
	{
		if(isalpha(*start) && isalpha(*end) && (toupper(*start++) != toupper(*end--)))
			return False;
		if(!isalpha(*start))
			start++;
		if(!isalpha(*end))
			end--;
	}
	return True;
}
