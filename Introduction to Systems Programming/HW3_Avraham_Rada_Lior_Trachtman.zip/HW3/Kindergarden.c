
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Kindergarden.h"

const char* namesOfTypes[NofTypes] = {"Chova","Trom Chova","Trom Trom Chova"};

// Print kindergarden with all children in
void printKindergarden(const Kindergarden* kg)
{
	int i;
	printf("Name: %s    ",kg->nameOfKindergarden);
	printf("Type: %s    ",namesOfTypes[kg->theType]);
	printf("%d Children:\n",kg->numOfChildren);
	for (i = 0; i < kg->numOfChildren; i++)
		printChild(kg->arrOfChildren[i]);
}

/*
 * initializing kindergarden according to details usr entering...
 * In - pointer to Kindergarden,nameOfKindergarden - new name of kindergarden to add,type of garden,number of children in garden
 * and array of all children!
 * Out - nothing
 */
void initKindergarden(Kindergarden* kg,char* nameOfKindergarden,typeOfKinderGarden theType,Child** arrOfChildren,int numOfChildren)
{
	long id;
	int i,age;
	for (i = 0; i < numOfChildren; i++)
	{
		printf("ID No.:\n");
		scanf("%ld",&id);
		printf("Age:\n");
		scanf("%d",&age);

		arrOfChildren[i] = (Child*)malloc(sizeof(Child));
		initChild(arrOfChildren[i],id,age);
	}
	kg->nameOfKindergarden = strdup(nameOfKindergarden);
	kg->theType = (typeOfKinderGarden)theType;
	kg->arrOfChildren = arrOfChildren;
	kg->numOfChildren = numOfChildren;
}

// Saving kindergarden details with all children to file
void saveKindergardenToFile(FILE* fp,const Kindergarden* kg)
{
	int i;
	fprintf(fp,"%s %d %d\n",kg->nameOfKindergarden,kg->theType,kg->numOfChildren);
	for (i = 0; i < kg->numOfChildren; i++)
		saveChildToFile(fp,kg->arrOfChildren[i]);
}

// Reading kindergarden details with all children from file
int readKindergardenFromFile(FILE* fp,Kindergarden* kg)
{
	int type,i;
	char tmp[MAX_LENGTH_OF_WORD]; // According to Efrat we can assume size is one word less that 100

	fscanf(fp,"%s",tmp);
	kg->nameOfKindergarden = strdup(tmp);
	if(!kg->nameOfKindergarden) // if allocation of name didnt work well
		return 0;

	fscanf(fp,"%d",&type);
	kg->theType = (typeOfKinderGarden)type;

	fscanf(fp,"%d",&kg->numOfChildren);
	kg->arrOfChildren = (Child**)malloc(sizeof(Child*) * (kg->numOfChildren));
	if(!kg->arrOfChildren)  // if allocation of arrOfChildren didnt work well
		return 0;

	for (i = 0; i < kg->numOfChildren; i++)
	{
		kg->arrOfChildren[i] = (Child*)malloc(sizeof(Child));
		if(!kg->arrOfChildren[i])  // if allocation of children didnt work well
			return 0;

		readChildFromFile(fp,kg->arrOfChildren[i]);
	}

	return 1;
}

/*
 * release memory resources of malloc/calloc/realloc function
 * In  - pointer of city
 * Out - nothing
 */
void releaseKindergarden(Kindergarden* kg)
{
	int i;
	free(kg->nameOfKindergarden); // free to the name of the kindergarden
	for (i = 0; i < kg->numOfChildren; i++)
		free(kg->arrOfChildren[i]);
	free(kg->arrOfChildren); // free the entire array of children

}


