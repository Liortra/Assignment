
#ifndef CITY_H_
#define CITY_H_

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "Kindergarden.h"

typedef struct
{
	Kindergarden** arrOfKinderGardens;
	int numOfKindergardens;
}City;

void readCity(City* city);
void showCityGardens(const City* city);
void showSpecificGardenInCity(City* city);
void saveCity(const City* city);
void cityAddGarden(City* city);
int  searchGardenInCity(City* city,const char* str);
int  searchChildInGarden(Kindergarden* kg, long id);
void birthdayToChild(City* city);
int  countChova(City* city);
void ReleaseCity(City* city);
void addChildToSpecificGardenInCity(City* city);
int  checkIfChildrenExist(Child** arrOfChildren,int numOfChildren,long id);

#endif /* CITY_H_ */
