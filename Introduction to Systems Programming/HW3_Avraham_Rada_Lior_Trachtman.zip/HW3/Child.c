
#include <stdio.h>
#include "Child.h"

// Printing child to screen
void printChild(const Child* child)
{
	printf("ID: %ld, Age: %d\n",child->id,child->age);
}

// Initializing child
void initChild(Child* child,long id,int age)
{
	child->id = id;
	child->age = age;
}

// Saving child details to file
void saveChildToFile(FILE* fp,const Child* child)
{
	fprintf(fp,"%ld %d\n",child->id,child->age);
}

// Reading details from file to Child struct
void readChildFromFile(FILE* fp, Child* child)
{
	 fscanf(fp,"%ld",&child->id);
	 fscanf(fp,"%d",&child->age);
}
