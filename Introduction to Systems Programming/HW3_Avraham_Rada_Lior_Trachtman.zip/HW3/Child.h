
#ifndef CHILD_H_
#define CHILD_H_

typedef struct
{
	long id;
	int age;
}Child;

void printChild(const Child* child);
void initChild(Child* child,long id,int age);
void saveChildToFile(FILE* fp,const Child* child);
void readChildFromFile(FILE* fp, Child* child);
#endif /* CHILD_H_ */
