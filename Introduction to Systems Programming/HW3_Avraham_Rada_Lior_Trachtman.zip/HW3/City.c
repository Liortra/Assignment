
#include "City.h"

/* reads from text data all the details of city.
   In - pointer for city. Out - nothing */
void readCity(City* city)
{
	FILE* fp;
	int i;

	ReleaseCity(city);

	// Open a filetxt in read state
	fp = fopen(FILE_NAME,"r");
	if(!fp)	// failed open file: DataFile.txt
	{
		printf("ERROR ! failed opening the file: DataFile.txt\n");
		return;
	}
	// read from file number of kindergarden
	fscanf(fp,"%d",&city->numOfKindergardens);
	if(city->numOfKindergardens <= 0)
	{
		fclose(fp);
		printf("0 kindergardens in 'DataFile.txt'\n");
		return; // if there is no data to read - finish
	}
	city->arrOfKinderGardens = (Kindergarden**)malloc(sizeof(Kindergarden*) * (city->numOfKindergardens));
	if(!city->arrOfKinderGardens) // if allocation didnt work well
	{
		fclose(fp);
		printf("ERROR ! allocation of kindergarden's array failed !\n");
		return;
	}
	for (i = 0; i < city->numOfKindergardens; i++)
	{
		city->arrOfKinderGardens[i] = (Kindergarden*)malloc(sizeof(Kindergarden));
		if(!city->arrOfKinderGardens[i])// if allocation didnt work well
		{
			fclose(fp);
			printf("ERROR ! allocation of kindergarden failed !\n");
			return;
		}
		if(!readKindergardenFromFile(fp,city->arrOfKinderGardens[i]))
		{
			fclose(fp);
			printf("ERROR ! reading Kindergarden From File FAILED !");
			return;
		}
	}
	fclose(fp);
}

/* Show from text data all the details of city.
   In - pointer for city. Out - nothing */
void showCityGardens(const City* city)
{
	int i;
	for (i = 0; i < city->numOfKindergardens; i++)
	{
		printf("Kindergarten %d:\n",i + 1);
		printKindergarden(city->arrOfKinderGardens[i]);
		printf("\n");
	}
}

/* Show from text data details of specific garden from city.
   In - pointer for city. Out - nothing */
void showSpecificGardenInCity(City* city)
{
	int i,check = 0; // check argument checking if we already found kindergarden
	char str[MAX_LENGTH_OF_WORD]; // According to Efrat we can assume size is one word less that 100

	printf("Give me the Kindergarten Name:\n");
	scanf("%s",str);

	for (i = 0; (i < city->numOfKindergardens)&&(!check); i++)
	{
		if(strcmp(city->arrOfKinderGardens[i]->nameOfKindergarden,str) == 0)
		{
			printKindergarden(city->arrOfKinderGardens[i]);
			check = 1;
		}
	}

	if(!check)
		printf("No such Kindergarten");
}

/* Saves to text data all the details of city.
   In - pointer for city. Out - nothing */
void saveCity(const City* city)
{
	FILE* fp;
	int i;

	// opening file text in 'write' mode
	fp = fopen(FILE_NAME,"w+");
	if(!fp)
		printf("\nERROR with opening the file...\n");

	fprintf(fp,"%d\n",city->numOfKindergardens);
	for (i = 0; i < city->numOfKindergardens; i++)
	{
		saveKindergardenToFile(fp,city->arrOfKinderGardens[i]);
	}
	printf("City saved !");
	fclose(fp);
}

/* Adding a new kindergarden to the city
   In - pointer for city. Out - nothing */
void cityAddGarden(City* city)
{
	int type,countOfChildren;
	char str[MAX_LENGTH_OF_WORD];
	Child** arrOfChildren = NULL;

	printf("Name:\n");
	scanf("%s",str);

	if(searchGardenInCity(city,str) != -1) // if the kindergarden already exists...
		printf("Kindergarden already exist !\n");
	else
	{
		city->arrOfKinderGardens = (Kindergarden**)realloc(city->arrOfKinderGardens,sizeof(Kindergarden*) * (city->numOfKindergardens + 1));
		if(!city->arrOfKinderGardens) //problem to realloc arrOfKinderGardens
			printf("ERROR in realloc arrOfKinderGardens action !");

		city->arrOfKinderGardens[city->numOfKindergardens] = (Kindergarden*)malloc(sizeof(Kindergarden));
		if(!city->arrOfKinderGardens[city->numOfKindergardens]) //problem to malloc Kindergarden
			printf("ERROR in malloc action !");

		printf("Garden type:\n");
		printf("Enter 0 for Chova\n");
		printf("Enter 1 for Trom Chova\n");
		printf("Enter 2 for Trom Trom Chova\n");
		scanf("%d",&type);

		printf("Children count:\n");
		scanf("%d",&countOfChildren);
		arrOfChildren = (Child**)malloc(sizeof(Child*) * countOfChildren);

		// initializing kindergarden
		initKindergarden(city->arrOfKinderGardens[city->numOfKindergardens],str,type,arrOfChildren,countOfChildren);
		city->numOfKindergardens = city->numOfKindergardens + 1;
	}
}

/*
 * Helper method for 'cityAddGarden' that search if kindergarden is already exist in city.
 * In  - pointer to city,str - new name of kindergarden to add.
 * Out - index in array of found name
 */
int searchGardenInCity(City* city,const char* str)
{
	int i;
	for (i = 0; i < city->numOfKindergardens; i++)
	{
		if(strcmp(city->arrOfKinderGardens[i]->nameOfKindergarden,str) == 0)
			return i; // returning the index where we found the kindergarden
	}
	return -1; // if the kindergarden doesnt exist we will return false(-1)
}

/*
 * Method to add child to specific kindergarten.
 * In  - pointer to city
 * Out - nothing
 */
void addChildToSpecificGardenInCity(City* city)
{
	char str[MAX_LENGTH_OF_WORD];
	int positionOfKindergarden,childreNumber,age;
	long id;

	printf("Give me the Kindergarten Name:\n");
	scanf("%s",str);
	positionOfKindergarden = searchGardenInCity(city,str);
	if(positionOfKindergarden == -1) // if the kindergarden doesnt exist...
		printf("no such Kindergarten\n");
	else
	{
		childreNumber = city->arrOfKinderGardens[positionOfKindergarden]->numOfChildren; // after we found kindergarden we will save the num of children there !

		printf("ID No.:\n");
		scanf("%ld",&id);
		printf("Age:\n");
		scanf("%d",&age);

		if(checkIfChildrenExist(city->arrOfKinderGardens[positionOfKindergarden]->arrOfChildren,childreNumber,id) != -1)
			printf("Child is already exists !");
		else
		{
			// realloc array of children with +1 child
			city->arrOfKinderGardens[positionOfKindergarden]->arrOfChildren = (Child**)realloc(city->arrOfKinderGardens[positionOfKindergarden]->arrOfChildren,
					sizeof(Child*) * (childreNumber + 1));
			if(!city->arrOfKinderGardens[positionOfKindergarden]->arrOfChildren) //problem to realloc arrOfChildren
				printf("ERROR in realloc arrOfChildren action !");

			city->arrOfKinderGardens[positionOfKindergarden]->arrOfChildren[childreNumber] = (Child*)malloc(sizeof(Child));
			initChild(city->arrOfKinderGardens[positionOfKindergarden]->arrOfChildren[childreNumber],id,age);
			city->arrOfKinderGardens[positionOfKindergarden]->numOfChildren = childreNumber + 1;
		}
	}
}

/*
 * Helper method for 'addChildToSpecificGardenInCity' that check if child's ID is already exist in garden.
 * In  - array of child's pointer,numOfChildren and id to check
 * Out - index in array of found id
 */
int checkIfChildrenExist(Child** arrOfChildren,int numOfChildren,long id)
{
	int i;
	for (i = 0; i < numOfChildren; i++)
	{
		if(arrOfChildren[i]->id == id)
			return i;
	}
	return -1; // if ID of the child does not exist, return -1
}

int searchChildInGarden(Kindergarden* kg, long id)
{
	int i;
	for (i = 0; i < kg->numOfChildren; i++)
	{
		if(kg->arrOfChildren[i]->id == id)
			return i;
	}
	return -1;
}

/*
 * Method to add +1 for the age of a child
 * In  - pointer of city
 * Out - nothing
 */
void birthdayToChild(City* city)
{
	int positionOfKindergarden,childPos;
	long tmpId;
	char str[MAX_LENGTH_OF_WORD];
	Kindergarden* kg;

	printf("Give me the Kindergarten Name:\n");
	scanf("%s",str);
	positionOfKindergarden = searchGardenInCity(city,str);
	if(positionOfKindergarden == -1) // if the kindergarden doesnt exist...
		printf("Kindergarden doesnt exist !\n");
	else
	{
		kg = city->arrOfKinderGardens[positionOfKindergarden];

		printf("Enter child id:\n");
		scanf("%ld",&tmpId);

		childPos = searchChildInGarden(kg,tmpId); // searching tmpId inside kindergarden and return position of child
		if(childPos == -1)
			printf("No such child\n");
		else
		{
			kg->arrOfChildren[childPos]->age = (kg->arrOfChildren[childPos]->age) + 1;
		}
	}
}

/*
 * Method that count the number of children in kindergarden type "Chova" and return it.
 * In  - pointer of city
 * Out - number of Chova
 */
int countChova(City* city)
{
	typeOfKinderGarden type = Hova;
	int i,count = 0;
	for (i = 0; i < city->numOfKindergardens; i++)
	{
		if(city->arrOfKinderGardens[i]->theType == type)
			count+=city->arrOfKinderGardens[i]->numOfChildren;
	}
	return count;
}

/*
 * release memory resources of malloc/calloc/realloc function
 * In  - pointer of city
 * Out - nothing
 */

void ReleaseCity(City* city)
{
	int i;
	for (i = 0; i < city->numOfKindergardens; i++)
	{
		releaseKindergarden(city->arrOfKinderGardens[i]);
		free(city->arrOfKinderGardens[i]);
	}
	free(city->arrOfKinderGardens);
}

