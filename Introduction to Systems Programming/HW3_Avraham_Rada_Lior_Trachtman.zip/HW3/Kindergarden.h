

#ifndef KINDERGARDEN_H_
#define KINDERGARDEN_H_

#define MAX_LENGTH_OF_WORD 100
#define FILE_NAME "DataFile.txt"

#include "Child.h"

typedef enum{Hova,TromHova,TromTromHova,NofTypes} typeOfKinderGarden;

typedef struct
{
	char* nameOfKindergarden;
	typeOfKinderGarden theType;
	Child** arrOfChildren;
	int numOfChildren;
}Kindergarden;

void printKindergarden(const Kindergarden* kg);
void initKindergarden(Kindergarden* kg,char* nameOfKindergarden,typeOfKinderGarden theType,Child** arrOfChildren,int numOfChildren);
void saveKindergardenToFile(FILE* fp,const Kindergarden* kg);
int  readKindergardenFromFile(FILE* fp,Kindergarden* kg);
void releaseKindergarden(Kindergarden* kg);
void releaseChild(Child* child);

#endif /* KINDERGARDEN_H_ */
