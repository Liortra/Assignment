#ifndef __HELP__
#define __HELP__

void swap(int *a, int *b);
void PrintMatrix(const int *matrix,int rows,int cols);

#endif
