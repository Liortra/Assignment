#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

#include "game1.h"
#include "game2.h"

void main()
{
	int endOfProg = 0;  // a flag for ending the program or not
	char usrChoice;		// saving the user choice

	do
	{
		printf("Please choose one of the following options:\n");
		printf("P/p - Picture Manipulation.\n");
		printf("N/n - Number Game.\n");
		printf("E / e - Quit.\n");

		// dealing with white-space characters
		do
		{
			scanf("%c", &usrChoice);
		} while (isspace(usrChoice));

		switch (usrChoice)
		{
			case 'p'  :
			case 'P'  :
				PictureManipulation();
				break;
			case 'N'  :
			case 'n'  :
				NumberGame();
				break;
			case 'E'  :
			case 'e'  :
				printf("Bye Bye\n");
				endOfProg = 1;
				break;
			default:
				printf("Wrong input! \nPlease enter your choice again...\n\n");
				break;
		}
	} while (!endOfProg);
}
