#include <stdio.h>
#include <time.h>
#include "game1.h"
#include "help.h"

void PictureManipulation()
{
	int matrix[SIZE][SIZE];

	srand(time(NULL));   // Initialization, should only be called once.
	buildMatrix((int*) matrix,SIZE,SIZE);
	PrintMatrix((int*) matrix,SIZE,SIZE);
    int endOfMenu = 0;
    int usrChoice;

    do
    {
    	printf("Please choose one of the following options:\n");
    	printf("1  - 90 degree clockwise\n");
    	printf("2  - 90 degree counter clockwise\n");
    	printf("3  - Flip Horizontal\n");
    	printf("4  - Flip Vertical\n");
    	printf("-1 - Quit\n");
    	scanf("%d", &usrChoice);

    	switch (usrChoice)
    	{
    		case 1 :
    			degree_clockwise((int*)matrix,SIZE);
    	    	break;
    	    case 2  :
    	      	degree_counter_clockwise((int*)matrix,SIZE);
    	      	break;
    	    case 3 :
    	      	Flip_Horizontal((int*)matrix,SIZE);
    	      	break;
    	    case 4 :
    	      	Flip_Vertical((int*)matrix,SIZE);
    	      	break;
    	    case -1  :
    	      	endOfMenu=1;
    	      	break;
    	    default:
    	      	printf("Wrong input! Please enter your choice again...\n");
    	      	break;
    	}
	} while (!endOfMenu);
}

//----------------------------------------------------------
void buildMatrix(int* matrix,int row, int col)
{
	int i,j;
	for (i=0; i<row ; i++)
		{
			for (j=0; j<col ; j++)
			{
				*(matrix+i*row+j) = MIN_1 + (rand() % (MAX_1-MIN_1+1));
			}
		}
}

//----------------------------------------------------------
void degree_clockwise(int* mat,int size)
{
	int level = 0,i;
	int last = size -1;
	int allLevels = size / 2;
	while(level < allLevels)
	{
		for(i=level;i<last;i++)
		{
			swap(mat+(level*size)+i,mat+(i*size)+last);
			swap(mat+(level*size)+i,mat+(last*size)+(last-i+level));
			swap(mat+(level*size)+i,mat+((last-i+level)*size)+level);
		}
		++level;
		--last;
	}
	printf("‫‪---------‬‬ ‫‪picture‬‬ ‫‪after‬‬ ‫‪manipulation‬‬ ‫‪---------‬‬\n");
	PrintMatrix((int*) mat,size,size);
}

//----------------------------------------------------------
void degree_counter_clockwise(int* mat,int size)
{
	int level = 0,i;
	int last = size-1;
	int allLevels = size/2;
	while(level < allLevels)
	{
		for(i=level;i<last;i++)
		{
			swap(mat+(i*size)+level,mat+(last*size)+i);
			swap(mat+(i*size)+level,mat+((last-i+level)*size)+last);
			swap(mat+(i*size)+level,mat+(level*size)+(last-i+level));
		}
		++level;
		--last;
	}
	printf("‫‪---------‬‬ ‫‪picture‬‬ ‫‪after‬‬ ‫‪manipulation‬‬ ‫‪---------‬‬\n");
	PrintMatrix((int*) mat,size,size);
}	

//----------------------------------------------------------
void Flip_Horizontal(int* mat,int size)
{
	int i,j;
	int level = size/2;
	for(i=0;i<level;i++)
	{
		for(int j=0;j<size;j++)
			swap(mat+(j*size)+(size-1-i),mat+(j*size)+i);
	}
	printf("‫‪---------‬‬ ‫‪picture‬‬ ‫‪after‬‬ ‫‪manipulation‬‬ ‫‪---------‬‬\n");
	PrintMatrix((int*) mat,size,size);
}

//----------------------------------------------------------
void Flip_Vertical(int* mat,int size)
{
	int i,j;
	int level = size/2;
	for(i=0;i<level;i++)
	{
		for(j=0;j<size;j++)
			swap(mat+((size-1-i)*size)+j,mat+(i*size)+j);
	}
	printf("‫‪---------‬‬ ‫‪picture‬‬ ‫‪after‬‬ ‫‪manipulation‬‬ ‫‪---------‬‬\n");
	PrintMatrix((int*) mat,size,size);
}

