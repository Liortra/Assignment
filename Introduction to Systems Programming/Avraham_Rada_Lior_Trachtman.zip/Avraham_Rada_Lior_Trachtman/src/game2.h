#ifndef __GAME2__
#define __GAME2__

#define N 2  		// row of matrix
#define M 2			// col of matrix
#define SHUFFEL_COUNT 30

// defines for random
#define MIN 0		// minimum column and row value
#define MAX_ROW 1	// maximum row value
#define MAX_COL 1	// maximum column value

void initializeMatrix(int* mat,int row,int col);
void shuffleMatrix(int* mat,int row,int col);
int checkIfBoardOle(const int* game, int rows, int cols);
void findValue(const int* game,int* row_value,int* col_value,int value);
int checkNeibours(const int* game, int rows, int cols,int step);


#endif
