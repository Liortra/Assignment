#include <stdio.h>
#include "help.h"

//----------------------------------------------------------
void swap(int *a,int *b)
{
	int temp = *a;
	*a = *b;
	*b = temp;
}
//----------------------------------------------------------
void PrintMatrix(const int *matrix,int rows,int cols)
{
	int i, j;
	for(i=0;i<rows;i++)
	{
		for(j=0;j<cols;j++)
		{
			printf("%5d", *matrix);
			matrix++;
		}
		printf("\n");
	}
}

