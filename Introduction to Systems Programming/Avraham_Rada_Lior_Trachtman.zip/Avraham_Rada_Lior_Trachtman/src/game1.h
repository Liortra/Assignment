#ifndef __GAME1__
#define __GAME1__

#define SIZE 4
#define MIN_1 1
#define MAX_1 100

void PictureManipulation();
void buildMatrix(int* matrix,int row, int col);
void degree_clockwise(int* mat,int size);
void degree_counter_clockwise(int* mat,int size);
void Flip_Horizontal(int* mat,int size);
void Flip_Vertical(int* mat,int size);

#endif
