#include <stdio.h>
#include <time.h>
#include "game2.h"
#include "help.h"

void NumberGame()
{
	srand(time(NULL));
	int game[N][M];

	initializeMatrix((int* )game,N,M);
	printf("Matrix after initialize:\n");
	PrintMatrix((int* )game,N,M);
	
	shuffleMatrix((int *)game,N,M); // method to shuffle the matrix after initializing...

	printf("Matrix after shuffling:\n");
	PrintMatrix((int* )game,N,M);

	int check = 0; // checks if game is over
	int checkIfWin = 0; // finish or not for do-while
	int checkStep = 0;
	int step, row_zero, col_zero,row_step,col_step;

	do
	{
		check = checkIfBoardOle((int* )game, N, M);
		if (check == (N*M))
		{
			printf("You win! The game is over!\n");
			checkIfWin = 1;
		}
		else
		{
			checkStep = 0;
			do
			{
				printf("Your step: ");
				scanf("%d", &step);

				if (step < 0 || step >= (N*M) || (!(checkNeibours((int* )game,N,M,step))))
					printf("Wrong step! please try again...\n");
				else
					checkStep = 1;
			} while (!checkStep);

			findValue((int* )game, &row_zero, &col_zero,0); 	// position of zero on board
			findValue((int* )game, &row_step, &col_step, step);	// position of step on board
			swap((((int*)game) +row_zero*M + col_zero), (((int* )game) + row_step*M + col_step));
			PrintMatrix((int* )game,N,M);
		}
	} while (!checkIfWin);
		
}

//----------------------------------------------------------
int checkIfBoardOle(const int* game, int rows, int cols)
{
	int temp = 1,i,j;
	int endLoopFlag = 0;
	for (i = 0; (i < rows)&&(!endLoopFlag); i++)
	{
		for (j = 0; (j < cols) && (!endLoopFlag); j++)
		{
			if (*(game+i*cols+j) != temp)
				endLoopFlag = 1;
			else
				temp++;
		}
	}
	return temp;
}

//----------------------------------------------------------
int checkNeibours(const int* game, int rows, int cols,int step)
{
	int row_zero, col_zero;

	findValue(game, &row_zero, &col_zero,0);

	// checking UP
	if ((row_zero - 1 >= 0) && (*(game + (row_zero-1)*cols +col_zero) == step))
		return 1;
	// Checking RIGHT
	else if ((col_zero + 1 < cols) && (*(game + row_zero*cols + (col_zero + 1)) == step))
		return 1;
	// Checking DOWN
	else if ((row_zero + 1 < rows) && (*(game + (row_zero + 1)*cols +col_zero) == step))
		return 1;
	// Checking
	else if ((col_zero - 1 >= 0) && (*(game + row_zero*cols + (col_zero - 1)) == step))
		return 1;
	else
		return 0;
}

//----------------------------------------------------------
// Method to get row and column number of value
void findValue(const int* game,int* row_value,int* col_value,int value)
{
	int end = 0;
	int i, j;
	for (i = 0; i < N && !end; i++)
	{
		for (j = 0; j < M && !end; j++)
		{
			if (*(game + i*M + j) == value)
			{
				*row_value = i;
				*col_value = j;
				end = 1;
			}
		}
	}
}

//----------------------------------------------------------
void initializeMatrix(int* mat,int row,int col)
{
	int start = 0,i,j;
	for (i = 0; i < row; i++)
	{
		for (j = 0; j < col; j++)
		{
			*(mat + i*col + j) = start++;
		}
	}
}

//----------------------------------------------------------
void shuffleMatrix(int* mat,int row,int col)
{
	int i;
	int first_row_index;
	int first_col_index;
	int second_row_index;
	int second_col_index;

	for (i = 0; i < SHUFFEL_COUNT; i++)
	{
		first_row_index = MIN + (rand() % (MAX_ROW-MIN+1));
		first_col_index = MIN + (rand() % (MAX_COL-MIN+1));

		second_row_index = MIN + (rand() % (MAX_ROW-MIN+1));
		second_col_index = MIN + (rand() % (MAX_COL-MIN+1));

		swap(mat + first_row_index*col +first_col_index,mat + second_row_index*col +second_col_index);
	}
}
