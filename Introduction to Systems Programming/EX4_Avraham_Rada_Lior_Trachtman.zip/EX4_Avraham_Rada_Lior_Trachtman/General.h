#ifndef __PROTOTYPE__
#define __PROTOTYPE__

typedef enum
{
	EXIT,
	READ_CITY,
	SHOW_CITY,
	SHOW_GARDEN,
	WRITE_CITY,
	ADD_GARDEN,
	ADD_CHILD,
	CHILD_BIRTHDAY,
	COUNT_GRADUATE,
	SORT_BY_NAME,
	SORT_BY_TYPE_AND_CHILDREN,
	SORT_BY_ID,
	LINKED_LIST_KINDERGARTEN,
	NofOptions
} MenuOptions;


int		menu();
char*	getStrExactLength(char* inpStr);
int		checkAllocation(const void* p);

int getSubNumber(char ch, int high, int low);
unsigned char createMask(int high, int low);

#endif
