#include <stdio.h>
#include <stdarg.h>

#include "City.h"
#include "Kindergarten.h"


/**************************************************/
/*     Read a city from a text/binary file file   */
/**************************************************/
void readCity(City* pCity,int binOrTxt)
{
	if (pCity->pGardenList != NULL) {
		releaseCity(pCity);
		pCity->count = 0;
	}

	// deciding which file to read according to MACRO fileName
	pCity->pGardenList = readAllGardensFromFile(fileName(binOrTxt), &pCity->count,binOrTxt);
	if (pCity->pGardenList == NULL)
		printf("Error reading city information\n");
}

/***********************************************************************/
/* Generic func to print pairs of parameters: name and children count  */
/***********************************************************************/
void printGarden(void* gardenName, ...)
{
	va_list params;
	char*   currentName;
	int     currentCount;

    va_start(params, gardenName);
	currentName = (char*)gardenName;
	while (currentName != NULL)
	{
		currentCount = va_arg(params, int);
		printf("%-10s ----> %d\n", currentName, currentCount);
		currentName = va_arg(params, char*);
	}
    va_end(params);
}


void	showCityGardens(City* pCity)
{
	showAllGardens(pCity->pGardenList, pCity->count);

	if(pCity->count >= 3)
	{
		printf("Kindergarten Info:\n");
		printGarden(pCity->pGardenList[0]->name,pCity->pGardenList[0]->childCount,
					pCity->pGardenList[1]->name,pCity->pGardenList[1]->childCount,
					pCity->pGardenList[2]->name,pCity->pGardenList[2]->childCount,NULL);
	}
}

void	showSpecificGardenInCity(City* pCity)
{
	showGardenMenu(pCity->pGardenList, pCity->count);
}

/**************************************************/
/*         Save city to a binary/text file        */
/**************************************************/
void saveCity(City* pCity,int binOrTxt)
{
	writeGardensToFile(pCity->pGardenList, pCity->count, fileName(binOrTxt),binOrTxt);
}

void cityAddGarden(City* pCity)
{
	pCity->pGardenList = addGarden(pCity->pGardenList, &pCity->count);
	if (pCity->pGardenList == NULL)//Allocation error
		printf("Error adding kindergarten\n");
}

void	addChildToSpecificGardenInCity(City* pCity)
{
	addChildToGarden(pCity->pGardenList, pCity->count);
}

void	birthdayToChild(City* pCity)
{
	handleBirthdayToChild(pCity->pGardenList, pCity->count);
}

int	countChova(City* pCity)
{
	int i;
	int count = 0;
	for (i = 0; i < pCity->count; i++)
	{
		if (pCity->pGardenList[i]->type == Chova)
			count += pCity->pGardenList[i]->childCount;
	}
	return count;
}

void	releaseCity(City* pCity)
{
	release(pCity->pGardenList, pCity->count);
}

void sort(City* pCity, int op,int binOrTxt)
{
	Garden* pGarden;
	if(op == 9)
		insertionSort(pCity->pGardenList,pCity->count,sizeof(pCity->pGardenList),compareGardenByNameLexicographic);
	else if (op == 10)
		insertionSort(pCity->pGardenList,pCity->count,sizeof(pCity->pGardenList),compareGardenByTypeAndNumOfChildren);
	else
	{
		pGarden = getGardenAskForName(pCity->pGardenList,pCity->count);
		insertionSort(pGarden->childPtrArr,pGarden->childCount,sizeof(pGarden->childPtrArr),compareChildrenById);
	}
}

void insertionSort(void* arr,int length, int size,int (*compare)(const void*, const void*))
{
	int i,j;
	void* key = (void*)malloc(size);
	if(!key)
		printf("Error with creating malloc for key!\n");
	for (i = 1; i < length; i++)
	{
		key = memcpy(key,arr+i*size,size);
		for(j=i-1; j>=0 && (compare(arr + j*size,key)) > 0; j--)
			memcpy(arr + (j + 1)*size,arr + j*size,size);
		memcpy(arr + (j + 1)*size,key,size);
	}
	free(key);
}


int compareGardenByNameLexicographic(const void* str1, const void* str2)
{
	const Garden* pG1 = *(const Garden**)str1;
	const Garden* pG2 = *(const Garden**)str2;
	return strcmp(pG1->name,pG2->name);
}

int compareChildrenById(const void* ch1, const void* ch2)
{
	const Child* pC1 = *(const Child**)ch1;
	const Child* pC2 = *(const Child**)ch2;
	return ((pC1->id) - (pC2->id));
}

int compareGardenByTypeAndNumOfChildren(const void* str1, const void* str2)
{
	const Garden* pG1 = *(const Garden**)str1;
	const Garden* pG2 = *(const Garden**)str2;
	if(pG1->type - pG2->type != 0)
		return pG1->type - pG2->type;
	else
		return pG1->childCount - pG2->childCount;
}

/*
 * functions for LIST
 */

void* createLinkedListForKindergartenType(City* pCity,GardenType  type)
{
	int i;
	List* list = (List*)malloc(sizeof(List));
	Node* newN;

	if(!initList(list))
	{
		printf("Failed to initialize list");
		return NULL;
	}

	newN = &list->head;
	for (i = 0; i < pCity->count; i++)
	{
		if(pCity->pGardenList[i]->type == type)
			newN = insertList(newN,pCity->pGardenList[i]);
	}
	return list;
}

int initList (List* pList)
{
	if (pList == NULL)
		return 0;

	pList->head.next = NULL;
	return 1;
}

Node* insertList(Node* pNode, Garden* key)
{
	Node* newN;
	if (pNode == NULL)
		return NULL;
	newN = (Node*)malloc(sizeof(Node));
	if(!newN)
		return NULL;

	newN->key = key;
	newN->next = pNode->next;
	pNode->next = newN;

	return newN;
}

void displayKindergartensFroList(List* list)
{
	Node* newN = list->head.next;
	printf("Kindergartens list:\n");

	while(newN != NULL)
	{
		showGarden((Garden*)newN->key);
		printf("\n");
		newN = newN->next;
	}
}

void kindergartensLinkedList(City* pCity)
{
	int typeGarden;
	List* list;
	typeGarden = getTypeOption();
	list = createLinkedListForKindergartenType(pCity,((GardenType)typeGarden));
	displayKindergartensFroList(list);
	if(!freeList(list))
		printf("Error with free the list");
}

int freeList(List* pList)
{
	Node* tmp;

	if (!pList)
		return 0;

	for (tmp = &(pList->head);  deleteNode(tmp);) ;
	return 1;
}

int deleteNode(Node* pNode)
{
	Node* tmp;
	if (!pNode || !(tmp = pNode->next))
		return 0;
	pNode->next = tmp->next;
	free(tmp);
	return 1;
}
