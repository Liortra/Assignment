#include <stdio.h>
#include <stdlib.h>

#include "General.h"
#include "Kindergarten.h"
#include "Child.h"
#include "City.h"

int main(int argc,char* argv[])
{
	int binOrTxt;

	sscanf(argv[1],"%d",&binOrTxt); // reading parameter from main

	if (argc > 2)
		return EXIT_SUCCESS;
	
	City utz = { NULL,0 };
	int uReq;

	//first time read
	readCity(&utz,binOrTxt);
	do
	{
		uReq = menu();
		switch (uReq)
		{
		case  READ_CITY:
			readCity(&utz,binOrTxt);
			break;

		case  SHOW_CITY:
			showCityGardens(&utz);
			break;

		case  SHOW_GARDEN:
			showSpecificGardenInCity(&utz);
			break;

		case  WRITE_CITY:
			saveCity(&utz,binOrTxt);
			break;

		case  ADD_GARDEN:
			cityAddGarden(&utz);
			break;

		case  ADD_CHILD:
			addChildToSpecificGardenInCity(&utz);
			break;

		case  CHILD_BIRTHDAY:
			birthdayToChild(&utz);
			break;

		case COUNT_GRADUATE:
			printf("There are %d children going to school next year\n",countChova(&utz));
			break;

		case  SORT_BY_NAME:
			sort(&utz,(int)SORT_BY_NAME,binOrTxt);
			break;

		case  SORT_BY_TYPE_AND_CHILDREN:
			sort(&utz,(int)SORT_BY_TYPE_AND_CHILDREN,binOrTxt);
			break;

		case  SORT_BY_ID:
			sort(&utz,(int)SORT_BY_ID,binOrTxt);
			break;

		case  LINKED_LIST_KINDERGARTEN:
			kindergartensLinkedList(&utz);
			break;

		}
	}while (uReq!=EXIT);

	releaseCity(&utz);//free all allocations

	return EXIT_SUCCESS;
}

