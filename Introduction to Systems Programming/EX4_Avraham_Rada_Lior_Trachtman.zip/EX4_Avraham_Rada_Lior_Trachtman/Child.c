#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Child.h"
#include "General.h"


/**************************************************/
/*             Read a Child from a text file      */
/**************************************************/
void readChild(FILE* fp, Child* pChild)
{
	//Child ID
	fscanf(fp, "%d", &pChild->id);
	fscanf(fp, "%d", &pChild->age);
}

/**************************************************/
/*       Read a Child from a binary file    	  */
/**************************************************/
void readChildFromBinary(FILE* fp, Child* pChild)
{
	unsigned char byte1,byte2;
	int tmpId = 0;
	int tmpAge = 0;

	fread(&byte1,sizeof(unsigned char),1,fp);
	fread(&byte2,sizeof(unsigned char),1,fp);

	// decoding byte with bitwise operation on masked byte
	tmpId = tmpId | (createMask(4,0) & byte2);
	tmpId = (tmpId << 8)|byte1;
	tmpAge = (tmpAge | (createMask(7,5) & byte2)) >> 5 ;
	pChild->id = tmpId;
	pChild->age = tmpAge;
}


/**************************************************/
/*            show a Child				          */
/**************************************************/
void showChild(const Child* pChild)
{
	printf("\nID:%d  ", pChild->id);
	printf("Age:%d  ", pChild->age);
}


/**************************************************/
void getChildFromUser(Child* pChild, int id)
/**************************************************/
/**************************************************/
{
	pChild->id = id;
	
	puts("\nAge:\t");
	scanf("%d", &pChild->age);
}


/**************************************************/
/*Write a Child to the open file				  */
/**************************************************/
void writeChild(FILE* fp,const Child* pChild)
{
	fprintf(fp,"%d %d\n",pChild->id, pChild->age);
}

/**************************************************/
/*Write a Child to the open binary file			  */
/**************************************************/
void writeChildB(FILE* fp,const Child* pChild)
{
	unsigned char byte1 = 0;
	unsigned char byte2 = 0;

	int tmpId = pChild->id;
	int tmpAge = pChild->age;

	byte1 = (unsigned char)(createMask(7,0) & tmpId);
	byte2 = (unsigned char)(((createMask(4,0) & (tmpId >> 8)) | (tmpAge << 5)));

	fwrite(&byte1,sizeof(unsigned char),1,fp);
	fwrite(&byte2,sizeof(unsigned char),1,fp);

}

int	findChildById(Child** pChildList, int count, int id)
{
	int index;
	Child ch = {id};
	Child* pCh = &ch;
	Child** pFound; // search the address of child we found or NULL if not found
	qsort(pChildList,count,sizeof(Child*),comparator);
	pFound = (Child**)bsearch(&pCh,pChildList,count,sizeof(Child*),comparator);

	if(!pFound)
	{
		return -1;
	}
	else
	{
		index = (int)(pFound - pChildList);
		return index;
	}
}

void birthday(Child* pChild)
{
	pChild->age++;
}

int comparator(const void* ch1, const void* ch2)
{
	const Child* pC1 = *(const Child**)ch1;
	const Child* pC2 = *(const Child**)ch2;
	return ((pC2->id) - (pC1->id));
}
