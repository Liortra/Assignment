#ifndef __CITY__
#define __CITY__

#include <stdlib.h>
#include <string.h>
#include "Kindergarten.h"
#define fileName(f) (f == 0) ? "DataFile.txt":"DataFile.bin"

typedef struct
{
	Garden** pGardenList;
	int count;
}City;

typedef struct node
{
	void* key;
	struct node* next;
}Node;

typedef struct
{
	Node head;
}List;

void  readCity(City* pCity,int binOrTxt);
void  showCityGardens(City* pCity);
void  showSpecificGardenInCity(City* pCity);
void  saveCity(City* pCity,int binOrTxt);
void  cityAddGarden(City* pCity);
void  addChildToSpecificGardenInCity(City* pCity);
void  birthdayToChild(City* pCity);
int	  countChova(City* pCity);
void  releaseCity(City* pCity);
void  readCityB(City* pCity);
void  sort(City* pCity,int op,int binOrTxt);
void  insertionSort(void* arr,int length, int size,int (*compare)(const void*, const void*));
int   compareGardenByNameLexicographic(const void* str1, const void* str2);
int   compareChildrenById(const void* ch1, const void* ch2);
int   compareGardenByTypeAndNumOfChildren(const void* str1, const void* str2);
void  printGarden(void* gardenName, ...);
void  displayKindergartensFromList(List* list);
void* createLinkedListForKindergartenType(City* pCity, GardenType gardenType);
void  kindergartensLinkedList(City* pCity);
int initList (List* pList);
Node* insertList(Node* pNode, Garden* key);
int freeList(List* pList);
int deleteNode(Node* pNode);

#endif
