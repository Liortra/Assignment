#ifndef __CHILD__
#define __CHILD__


typedef struct
{
	int	 id;
	int  age;
}Child;


void readChild(FILE* fp, Child* pChild);
void getChildFromUser(Child* pChild, int id);
void showChild(const Child* pChild);
void writeChild(FILE* fp,const Child* pChild);
void birthday(Child* pChild);
void readChildFromBinary(FILE* fp, Child* pChild);
void writeChildB(FILE* fp,const Child* pChild);
int	 findChildById(Child** pChildList, int count, int id);
int  comparator(const void* ch1, const void* ch2);

#endif
